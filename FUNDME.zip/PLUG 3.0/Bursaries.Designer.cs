﻿namespace PLUG_3._0
{
    partial class Bursaries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSibanye = new System.Windows.Forms.Button();
            this.btnSanlam = new System.Windows.Forms.Button();
            this.btnSasol = new System.Windows.Forms.Button();
            this.btnAnglo = new System.Windows.Forms.Button();
            this.btnCSIR = new System.Windows.Forms.Button();
            this.btnVoda = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnStudents = new System.Windows.Forms.Button();
            this.btnDonation = new System.Windows.Forms.Button();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.btnLogOut);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(786, 106);
            this.panel1.TabIndex = 6;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = global::PLUG_3._0.Properties.Resources.logo_removebg_preview;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(284, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(216, 106);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.ForeColor = System.Drawing.Color.OrangeRed;
            this.btnLogOut.Location = new System.Drawing.Point(698, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(75, 27);
            this.btnLogOut.TabIndex = 1;
            this.btnLogOut.Text = "Log out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Controls.Add(this.btnSibanye);
            this.panel3.Controls.Add(this.btnSanlam);
            this.panel3.Controls.Add(this.btnSasol);
            this.panel3.Controls.Add(this.btnAnglo);
            this.panel3.Controls.Add(this.btnCSIR);
            this.panel3.Controls.Add(this.btnVoda);
            this.panel3.Location = new System.Drawing.Point(-1, 195);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(786, 264);
            this.panel3.TabIndex = 8;
            // 
            // btnSibanye
            // 
            this.btnSibanye.BackgroundImage = global::PLUG_3._0.Properties.Resources.sibanye;
            this.btnSibanye.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSibanye.Location = new System.Drawing.Point(545, 136);
            this.btnSibanye.Name = "btnSibanye";
            this.btnSibanye.Size = new System.Drawing.Size(217, 118);
            this.btnSibanye.TabIndex = 6;
            this.btnSibanye.UseVisualStyleBackColor = true;
            this.btnSibanye.Click += new System.EventHandler(this.btnSibanye_Click);
            // 
            // btnSanlam
            // 
            this.btnSanlam.BackgroundImage = global::PLUG_3._0.Properties.Resources.Sanlam;
            this.btnSanlam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSanlam.Location = new System.Drawing.Point(285, 136);
            this.btnSanlam.Name = "btnSanlam";
            this.btnSanlam.Size = new System.Drawing.Size(242, 118);
            this.btnSanlam.TabIndex = 5;
            this.btnSanlam.UseVisualStyleBackColor = true;
            this.btnSanlam.Click += new System.EventHandler(this.btnSanlam_Click);
            // 
            // btnSasol
            // 
            this.btnSasol.BackgroundImage = global::PLUG_3._0.Properties.Resources.Sasol;
            this.btnSasol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSasol.Location = new System.Drawing.Point(45, 136);
            this.btnSasol.Name = "btnSasol";
            this.btnSasol.Size = new System.Drawing.Size(224, 118);
            this.btnSasol.TabIndex = 4;
            this.btnSasol.UseVisualStyleBackColor = true;
            this.btnSasol.Click += new System.EventHandler(this.btnSasol_Click);
            // 
            // btnAnglo
            // 
            this.btnAnglo.BackgroundImage = global::PLUG_3._0.Properties.Resources.anglo_american;
            this.btnAnglo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAnglo.Location = new System.Drawing.Point(545, 3);
            this.btnAnglo.Name = "btnAnglo";
            this.btnAnglo.Size = new System.Drawing.Size(217, 118);
            this.btnAnglo.TabIndex = 3;
            this.btnAnglo.UseVisualStyleBackColor = true;
            this.btnAnglo.Click += new System.EventHandler(this.btnAnglo_Click);
            // 
            // btnCSIR
            // 
            this.btnCSIR.BackgroundImage = global::PLUG_3._0.Properties.Resources.CSIR;
            this.btnCSIR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCSIR.Location = new System.Drawing.Point(285, 3);
            this.btnCSIR.Name = "btnCSIR";
            this.btnCSIR.Size = new System.Drawing.Size(242, 118);
            this.btnCSIR.TabIndex = 1;
            this.btnCSIR.UseVisualStyleBackColor = true;
            this.btnCSIR.Click += new System.EventHandler(this.btnCSIR_Click);
            // 
            // btnVoda
            // 
            this.btnVoda.BackgroundImage = global::PLUG_3._0.Properties.Resources.Vodacom;
            this.btnVoda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVoda.Location = new System.Drawing.Point(45, 3);
            this.btnVoda.Name = "btnVoda";
            this.btnVoda.Size = new System.Drawing.Size(224, 118);
            this.btnVoda.TabIndex = 0;
            this.btnVoda.UseVisualStyleBackColor = true;
            this.btnVoda.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.btnProfile);
            this.panel2.Controls.Add(this.btnStudents);
            this.panel2.Controls.Add(this.btnDonation);
            this.panel2.Controls.Add(this.btnAbout);
            this.panel2.Controls.Add(this.btnHome);
            this.panel2.Location = new System.Drawing.Point(0, 126);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(786, 63);
            this.panel2.TabIndex = 7;
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.Transparent;
            this.btnProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProfile.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.White;
            this.btnProfile.Location = new System.Drawing.Point(199, 3);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(136, 57);
            this.btnProfile.TabIndex = 1;
            this.btnProfile.Text = "BURSARIES";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnStudents
            // 
            this.btnStudents.BackColor = System.Drawing.Color.Transparent;
            this.btnStudents.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStudents.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnStudents.FlatAppearance.BorderSize = 0;
            this.btnStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudents.ForeColor = System.Drawing.Color.White;
            this.btnStudents.Location = new System.Drawing.Point(341, 3);
            this.btnStudents.Name = "btnStudents";
            this.btnStudents.Size = new System.Drawing.Size(136, 57);
            this.btnStudents.TabIndex = 2;
            this.btnStudents.Text = "STATUS";
            this.btnStudents.UseVisualStyleBackColor = false;
            this.btnStudents.Click += new System.EventHandler(this.btnStudents_Click);
            // 
            // btnDonation
            // 
            this.btnDonation.BackColor = System.Drawing.Color.Transparent;
            this.btnDonation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDonation.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDonation.FlatAppearance.BorderSize = 0;
            this.btnDonation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDonation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDonation.ForeColor = System.Drawing.Color.White;
            this.btnDonation.Location = new System.Drawing.Point(483, 3);
            this.btnDonation.Name = "btnDonation";
            this.btnDonation.Size = new System.Drawing.Size(136, 57);
            this.btnDonation.TabIndex = 3;
            this.btnDonation.Text = "MOTIVATION";
            this.btnDonation.UseVisualStyleBackColor = false;
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.Transparent;
            this.btnAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbout.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAbout.FlatAppearance.BorderSize = 0;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.Color.White;
            this.btnAbout.Location = new System.Drawing.Point(625, 3);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(136, 57);
            this.btnAbout.TabIndex = 4;
            this.btnAbout.Text = "ABOUT";
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Transparent;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.Location = new System.Drawing.Point(57, 3);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(136, 57);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "HOME";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // Bursaries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PLUG_3._0.Properties.Resources.BC13;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "Bursaries";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bursaries";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnStudents;
        private System.Windows.Forms.Button btnDonation;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnSibanye;
        private System.Windows.Forms.Button btnSanlam;
        private System.Windows.Forms.Button btnSasol;
        private System.Windows.Forms.Button btnAnglo;
        private System.Windows.Forms.Button btnCSIR;
        private System.Windows.Forms.Button btnVoda;
    }
}